实验环境
操作系统： Windows 11
软件工具： pycharm

实验报告
在main.tex中

代码和结果说明
实验中使用的代码为cp.py
结果已整理在实验报告中

安装所需的软件包：
numpy
matplotlib
gymnasium