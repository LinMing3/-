# SARSA
import numpy as np
import matplotlib.pyplot as plt
import gymnasium as gym
# Discrete(2)
# Box([-4.8               -inf -0.41887903        -inf], [4.8               inf 0.41887903        inf], (4,), float32)

# 这里是参数
alpha=0.45
gamma=0.99
episodes=1000
epsilon=0.024

# Q表
Q=np.zeros((10000,2))

env = gym.make('CartPole-v1',render_mode="rgb_array")
env.reset()

def get_action(state):
    index=get_state_index(state)
    if np.random.rand() < epsilon:  # 探索
        return np.random.choice([0, 1])  # CartPole 动作空间是 0 或 1
    return np.argmax(Q[index])  # 利用


# 重点调整对象,离散化
def get_state_index(state):
    v1=state[0]*900
    v2=state[1]*120
    v3=state[2]*900
    v4=state[3]*105
    return (int(v1+v2+v3+v4)+3000)//11

def Q_update(state, action, reward, next_state, next_action):
    state_index=get_state_index(state)
    next_state_index=get_state_index(next_state)
    Q[state_index][action]+=alpha*(reward+gamma*Q[next_state_index][next_action]-Q[state_index][action])


def train():
    global epsilon
    eps=[]
    steps = []
    for t in range(episodes):
        obs,info= env.reset()  # 重置环境并获取初始观测,S
        done = False  # 游戏是否结束的标志
        s=0
        action=get_action(obs)#选择一个action，A

        while not done:#重复，R
            s=s+1
            action=get_action(obs)#选择一个action，A

            obs_next, reward, terminated, truncated, _ = env.step(action)  # 执行动作并获取下一个状态和奖励

            # 更新action，A
            action_next = get_action(obs_next)

            # 更新Q
            Q_update(obs, action, reward, obs_next, action_next)

            # 更新obs，S
            obs = obs_next

            # 如果回合结束，则更新done状态
            done = terminated or truncated


        eps.append(t)
        steps.append(s)
    plt.plot(eps, steps)
    plt.show()
    plt.scatter(eps, steps)
    plt.show()
    print(f"1000次训练平均步数：{np.mean(steps)}")
    print(f"后500次训练平均步数：{np.mean(steps[500:])}")

def random():
    steps = []
    for t in range(500):
        obs, info = env.reset()  # 重置环境并获取初始观测,S
        done = False  # 游戏是否结束的标志
        s = 0
        action = env.action_space.sample()  # 选择一个action，A

        while not done:  # 重复，R
            s = s + 1
            action = env.action_space.sample()  # 选择一个action，A

            obs_next, reward, terminated, truncated, _ = env.step(action)  # 执行动作并获取下一个状态和奖励

            # 更新action，A
            action_next = get_action(obs_next)

            # 更新Q
            Q_update(obs, action, reward, obs_next, action_next)

            # 更新obs，S
            obs = obs_next

            # 如果回合结束，则更新done状态
            done = terminated or truncated

        steps.append(s)
    print(f"随机500次平均步数：{np.mean(steps)}")


random()
train()
env.close()


# 测试，动画效果
envi=gym.make('CartPole-v1',render_mode="human")
for t in range(3):
    obs,info= envi.reset()  # 重置环境并获取初始观测,S
    done = False  # 游戏是否结束的标志

    action = get_action(obs)  # 选择一个action，A
    epsilon=0
    while not done:  # 重复，R
        action = get_action(obs)  # 选择一个action，A

        obs_next, reward, terminated, truncated, _ = envi.step(action)  # 执行动作并获取下一个状态和奖励

        # 更新action，A
        action_next = get_action(obs_next)

        # 更新Q
        Q_update(obs, action, reward, obs_next, action_next)

        # 更新obs，S
        obs = obs_next

        # 如果回合结束，则更新done状态
        done = terminated or truncated

envi.close()


